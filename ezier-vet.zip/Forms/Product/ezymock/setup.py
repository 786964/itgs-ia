from setuptools import setup

setup(
    name="ezymock",
    version="0.1.0",
    author="Ben Burrill",
    py_modules=["ezymock"],
    install_requires=["flask"]
)
